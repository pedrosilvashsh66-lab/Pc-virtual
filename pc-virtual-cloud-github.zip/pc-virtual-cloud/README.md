# PC Virtual na Nuvem

Este projeto cria um desktop Linux completo (XFCE) acessível pelo navegador,
usando Webtop + Docker. É um ponto de partida para um PC remoto com navegador,
gerenciador de arquivos e aplicativos.

## Importante: o que ele é e o que não é

- É um desktop **Linux**, não Windows 11.
- O GitHub guarda o código; ele **não hospeda** o computador virtual.
- Você precisa executar este projeto em um servidor cloud que aceite Docker
  e permita expor as portas TCP 3000 e 3001.
- Para Minecraft 3D com desempenho razoável, o servidor precisa ter GPU
  compatível, drivers e aceleração gráfica. Um servidor gratuito comum,
  sem GPU, pode abrir o desktop, mas provavelmente terá desempenho ruim
  ou não conseguirá executar o jogo.
- Este projeto não cria uma máquina gratuita permanente nem contorna limites
  de serviços cloud.

## Arquivos

- `compose.yaml`: configura o desktop e armazenamento persistente.
- `Dockerfile`: usa a imagem LinuxServer Webtop com XFCE.
- `.env.example`: exemplo de usuário e senha.
- `.gitignore`: impede enviar o arquivo `.env` ao GitHub.

## Como publicar no GitHub pelo celular

1. Crie um repositório novo no GitHub, por exemplo `pc-virtual-cloud`.
2. Envie estes arquivos mantendo a estrutura de pastas.
3. Não envie senhas reais para o GitHub.

## Como executar em um servidor cloud com Docker

1. Entre no servidor por SSH.
2. Instale Docker Engine e o plugin Docker Compose conforme a documentação
   oficial da distribuição do servidor.
3. Clone seu repositório:
   `git clone URL_DO_SEU_REPOSITORIO`
4. Entre na pasta:
   `cd pc-virtual-cloud`
5. Crie o arquivo de configuração:
   `cp .env.example .env`
6. Edite `.env` e troque usuário e senha por valores fortes:
   `nano .env`
7. Inicie:
   `docker compose up -d --build`
8. Acesse `http://IP_DO_SERVIDOR:3000` ou, preferencialmente,
   configure HTTPS/reverse proxy e acesse pela porta 3001.

**Segurança:** não exponha o desktop aberto à internet sem senha e HTTPS.
Use firewall para limitar o acesso. Não compartilhe a senha. Se o provedor
oferecer rede privada ou VPN, prefira essa opção.

## Minecraft

O desktop é Linux. Para Minecraft Java, será necessário instalar um launcher
compatível dentro do desktop e aceitar os termos oficiais da Microsoft/Mojang.
O desempenho depende da GPU e dos drivers do servidor.

Minecraft Bedrock não tem suporte oficial equivalente para desktop Linux.
Se você joga Bedrock no celular/console, este projeto não garante que essa
edição funcione nele.

## GitHub Actions

GitHub Actions pode validar arquivos ou automatizar tarefas do repositório,
mas não deve ser usado como hospedagem de um PC remoto permanente. Os runners
são temporários, têm limites de uso e não são uma plataforma de streaming de
jogos.

## Custos

Antes de criar a máquina, confira os preços, limites, política de uso e
requisitos de idade do provedor cloud. Peça ajuda a um responsável para criar
a conta e revisar possíveis cobranças. "Free tier" pode ter limites e exigir
método de pagamento.
